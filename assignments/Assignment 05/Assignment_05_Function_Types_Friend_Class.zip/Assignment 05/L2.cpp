#include <iostream>
using namespace std;

class Box {
    int length;

public:
    // parameter name same as member name
    void setLength(int length) {
        this->length = length; // this->length = member, length = parameter
    }

    void show() {
        cout << "Length: " << this->length << endl;
    }
};

int main() {
    Box b;
    b.setLength(25);
    b.show();
    return 0;
}
