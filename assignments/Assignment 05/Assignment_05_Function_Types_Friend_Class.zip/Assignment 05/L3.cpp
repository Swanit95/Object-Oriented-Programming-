#include <iostream>
using namespace std;

class Math {
public:
    inline int square(int x) {
        return x * x;
    }
    inline int cube(int x) {
        return x * x *x;
    }
};

int main() {
    Math m;
    cout << "Square: " << m.square(5) << endl;
    cout << "Cube: " << m.cube(3) << endl;

    return 0;
}

// Note: Any function fully defined inside a class body is inline by default,
// even without the inline keyword.
class Demo {
public:
    int add(int a, int b) { return a + b; } // implicitly inline
};
