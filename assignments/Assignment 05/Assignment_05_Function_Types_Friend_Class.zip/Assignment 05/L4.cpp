#include <iostream>
using namespace std;

class Employee {
    int id;
    static int count; // static data member (declaration)

public:
    Employee() {
        count++;
        id = count;
    }

    static int getCount() { // static member function
        return count;
        // Note: static functions can ONLY access static data members
    }

    void showId() {
        cout << "Employee ID: " << id << endl;
    }
};

int Employee::count = 0; // static member definition (outside class)

int main() {
    Employee e1, e2, e3;
    e1.showId();
    e2.showId();
    e3.showId();

    // called using class name, no object needed
    cout << "Total employees: " << Employee::getCount() << endl;
    return 0;
}
