#include <bits/stdc++.h>
using namespace std;

class Demo {
public:
    // Function to add two integers
    void add(int a, int b) {
        cout << "Integer Sum = " << a + b << endl;
    }

    // Function to add two floating point values
    void add(double a, double b) {
        cout << "Float Sum = " << a + b << endl;
    }
};

int main() {
    Demo d;
    // add() called with int values
    d.add(10, 2);
    // add() called with double value
    d.add(5.3, 6.2);
    return 0;
}
