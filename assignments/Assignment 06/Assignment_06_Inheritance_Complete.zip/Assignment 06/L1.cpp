#include <iostream>
#include <string>
using namespace std;

class Student {
    int rollNo;
    string name;

public:
    void setData(int r, string n) {
        rollNo = r;
        name = n;
    }
    void display() {
        cout << "Roll No: " << rollNo << ", Name: " << name << endl;
    }
};

int main() {
    Student s1, s2;
    s1.setData(1, "Aditi");
    s2.setData(2, "Rohan");
    s1.display();
    s2.display();
    return 0;
}
