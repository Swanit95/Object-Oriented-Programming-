#include <iostream>
using namespace std;

class Animal{
    public:
    void eat(){
        cout << "Animal eats the food!" << endl;
    }
};

class Dog : public Animal {
    public:
    void bark(){
        cout << "Dog barks!" << endl;
    }
};

class Engine {
private:
    int horsepower;

public:
    Engine(int hp) : horsepower(hp) {}
    friend class Car; // Car is granted access to Engine's private members
};

class Car {
public:
    void showEnginePower(Engine& e) {
        // accessing Engine's private member directly
        cout << "Engine Horsepower: " << e.horsepower << " HP" << endl;
    }
};

int main(){
    Dog d1;
    d1.eat();
    d1.bark();
    return 0;
}
