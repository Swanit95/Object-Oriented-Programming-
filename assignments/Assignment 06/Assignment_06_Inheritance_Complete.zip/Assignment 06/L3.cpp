#include <iostream>
using namespace std;

class Grandparent {
public:
    void show1() {
        cout << "Grandparent class" << endl;
    }
};

class Parent: public Grandparent {
public:
    void show2() {
        cout << "Parent class" << endl;
    }
};

class Child: public Parent {
public:
    void show3() {
        cout << "Child class" << endl;
    }
};

int main() {
    Child c;
    c.show1();
    c.show2();
    c.show3();
    return 0;
}
