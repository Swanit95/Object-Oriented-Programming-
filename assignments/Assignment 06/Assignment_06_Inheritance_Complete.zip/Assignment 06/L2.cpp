#include <iostream>
using namespace std;

class Teacher{
    public:
    void teach(){
        cout << "teaches students!" << endl;
    }
};

class Researcher{
    public:
    void research(){
        cout << "conducts research!" << endl;
    }
};

class Student : public Teacher , public Researcher {
    public:
    void Study(){
        cout << "Student Learns!" << endl;
    }
};

int main(){
    Student s1;
    s1.teach();
    s1.research();
    s1.Study();
    return 0;
}
